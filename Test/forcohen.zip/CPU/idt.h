#pragma once

#define FLAG_SET(x, flag) x |= (flag)
#define FLAG_UNSET(x, flag) x &= ~(flag)

typedef struct 
{
    unsigned short baseLow;
    unsigned short segmentSelector;
    unsigned char reserved;
    unsigned char flags;
    unsigned short baseHigh;
} __attribute__((packed)) IDTEntry;

typedef struct 
{
    unsigned short limit;
    IDTEntry* ptr;
} __attribute__((packed)) IDTDescriptor;

typedef enum
{
    IDT_FLAG_GATE_TASK = 0x5,
    IDT_FLAG_GATE_16BIT_INT = 0x6,
    IDT_FLAG_GATE_16BIT_TRAP = 0x6,
    IDT_FLAG_GATE_32BIT_INT = 0x6,
    IDT_FLAG_GATE_32BIT_TRAP = 0x6,

    IDT_FALG_RING0 = (0 << 5),
    IDT_FALG_RING1 = (1 << 5),
    IDT_FALG_RING2 = (2 << 5),
    IDT_FALG_RING3 = (3 << 5),

    IDT_FLAG_PRESENT = 0x80,
} IDT_FLAGS;

void IDT_init();
void IDT_SetGate(int interrupt, void* base, unsigned short segmentDescriptor, unsigned char flags);
void IDT_enableGate(int interrupt);
void IDT_disableGate(int interrupt);
