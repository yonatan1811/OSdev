#include "idt.h"

IDTEntry g_IDT[32];

IDTDescriptor g_IDTDescriptor = {sizeof(g_IDT) - 1, g_IDT};

extern void idt_load(IDTDescriptor* idtDescriptor);

void IDT_SetGate(int interrupt, void* base, unsigned short segmentDescriptor, unsigned char flags)
{
    g_IDT[interrupt].baseLow = ((unsigned long)base) & 0xFFFF;
    g_IDT[interrupt].segmentSelector = segmentDescriptor;
    g_IDT[interrupt].reserved = 0;
    g_IDT[interrupt].flags = flags;
    g_IDT[interrupt].baseHigh = ((unsigned long)base >> 16) & 0xFFFF;
}

void IDT_enableGate(int interrupt)
{
    FLAG_SET(g_IDT[interrupt].flags, IDT_FLAG_PRESENT);
}

void IDT_disableGate(int interrupt)
{
    FLAG_UNSET(g_IDT[interrupt].flags, IDT_FLAG_PRESENT);
}

void IDT_init()
{
    idt_load(&g_IDT);
}
