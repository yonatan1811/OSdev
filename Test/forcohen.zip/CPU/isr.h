#pragma once

typedef struct
{
    unsigned long ds;
    unsigned long edi, esi, ebp, kernel_esp, ebx, edx, ecx, eax;
    unsigned long interrupt, error;
    unsigned long eip, cs, eflags, esp, ss;
} __attribute__((packed)) Registers;

void ISR_init();