#include "hal.h"

void HAL_Initialize()
{
    GDT_Init();
    IDT_init();
    ISR_init();
}
