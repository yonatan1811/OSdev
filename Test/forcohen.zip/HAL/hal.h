#pragma once

#include "../CPU/gdt.h"
#include "../CPU/idt.h"
#include "../CPU/isr.h"

void HAL_Initialize();